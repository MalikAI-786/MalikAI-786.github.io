BRAND KIT — YASIR A. MALIK
Audit · Risk · Governance

Folders are named for where the file goes, not for what type it is.

01  PROFILE PHOTO
    Use profile-photo-square.png on every profile: LinkedIn, GitHub,
    Substack, Gmail, Notion, Zoom. The same face in every place is most of
    what people mean by a consistent brand, and it costs one upload.
    The circular cut is transparent outside the circle, for slides.

02  COVERS
    LinkedIn cover is 1584x396, laid out clear of the mobile crop and the
    profile-photo circle. Pick dark or light and keep it — switching between
    them is the only wrong answer.

03  SPEAKER AND PRESS
    1600x900. Send this when a conference asks for a bio slide.

04  LOGO
    SVG, so it scales to a billboard or a favicon without redrawing.
    Use the micro cut below 32px: the full mark fills in at small sizes.
    Clear space is one ring radius on every side, minimum.

05  EMAIL SIGNATURE
    Open signature.html in a browser, select the whole block, copy, and
    paste into Gmail Settings > Signature. Table layout with inline styles,
    so it survives Outlook.

06  ACCOUNT AVATARS
    One letter per stream. Ember is the personal and marketplace accounts,
    verdigris is Malik LLC and the newsletter.

07  BUSINESS CARDS
    One folder per brand: yasir-a-malik (the default), consulting, malik-llc,
    malik-marketplace, proof-over-promise. Send the PDFs to a printer. The
    PNGs are for looking at.

08  SOCIAL AND ICONS

09  FOR A DESIGNER
    tokens.css is the palette, in full, with the usage rules as comments.
    tokens.json is the same palette as W3C Design Tokens, for other tools.
    templates.json is the typed index of every business card and email
    signature — for another AI agent picking this up, not for a human.

THE ONE COLOUR RULE
    Ember #E0662E is the brand, and it measures 3.11:1 on paper. It carries
    marks, rules and large display type. It can never carry body text on a
    light ground — use #AD4317 on light and #F58E5C on dark.

These files are outputs. Do not retouch a PNG or hand-edit an SVG; the change
will be lost the next time a generator runs. Everything here is produced from
one set of constants at:
    github.com/MalikAI-786/MalikAI-786.github.io  ->  assets/brand/

Full index with previews:  https://malikai-786.github.io/brand-assets.html
The system, documented:    https://malikai-786.github.io/brand.html


CONTENTS

  01 Profile photo/profile-photo-square.png              657 KB
  01 Profile photo/profile-photo-circle.png              732 KB
  01 Profile photo/portrait-duotone.png                  462 KB
  02 Covers/linkedin-cover-dark.png                       33 KB
  02 Covers/linkedin-cover-light.png                      33 KB
  02 Covers/github-hero-dark.png                         167 KB
  02 Covers/github-hero-light.png                        162 KB
  03 Speaker and press/speaker-card-dark.png             459 KB
  03 Speaker and press/speaker-card-light.png            468 KB
  04 Logo/mark.svg                                         0 KB
  04 Logo/mark-ember-on-light.svg                          0 KB
  04 Logo/mark-reversed-on-dark.svg                        0 KB
  04 Logo/mark-micro-under-32px.svg                        0 KB
  04 Logo/mark-badge.svg                                   0 KB
  04 Logo/lockup-horizontal.svg                            1 KB
  04 Logo/lockup-horizontal-reversed.svg                   1 KB
  04 Logo/lockup-stacked.svg                               1 KB
  04 Logo/wordmark.svg                                     0 KB
  04 Logo/wordmark-reversed.svg                            0 KB
  05 Email signature/signature.html                       17 KB
  05 Email signature/signature-mark.png                    8 KB
  06 Account avatars/A-yasir-a-malik.png                  37 KB
  06 Account avatars/M-malik-llc.png                      32 KB
  06 Account avatars/M-malik-marketplace.png              35 KB
  06 Account avatars/P-proof-over-promise.png             28 KB
  07 Business cards/yasir-a-malik/card-front-print.pdf    16 KB
  07 Business cards/yasir-a-malik/card-back-print.pdf      7 KB
  07 Business cards/yasir-a-malik/card-front-preview.png    42 KB
  07 Business cards/yasir-a-malik/card-back-preview.png    26 KB
  07 Business cards/consulting/card-front-print.pdf       16 KB
  07 Business cards/consulting/card-back-print.pdf         7 KB
  07 Business cards/consulting/card-front-preview.png     44 KB
  07 Business cards/consulting/card-back-preview.png      27 KB
  07 Business cards/malik-llc/card-front-print.pdf        14 KB
  07 Business cards/malik-llc/card-back-print.pdf          7 KB
  07 Business cards/malik-llc/card-front-preview.png      35 KB
  07 Business cards/malik-llc/card-back-preview.png       23 KB
  07 Business cards/malik-marketplace/card-front-print.pdf    13 KB
  07 Business cards/malik-marketplace/card-back-print.pdf     7 KB
  07 Business cards/malik-marketplace/card-front-preview.png    29 KB
  07 Business cards/malik-marketplace/card-back-preview.png    25 KB
  07 Business cards/proof-over-promise/card-front-print.pdf    15 KB
  07 Business cards/proof-over-promise/card-back-print.pdf     7 KB
  07 Business cards/proof-over-promise/card-front-preview.png    38 KB
  07 Business cards/proof-over-promise/card-back-preview.png    20 KB
  08 Social and icons/open-graph-card.png                 52 KB
  08 Social and icons/icon-512.png                        23 KB
  08 Social and icons/icon-192.png                         8 KB
  08 Social and icons/icon-32.png                          1 KB
  08 Social and icons/apple-touch-icon.png                 7 KB
  08 Social and icons/favicon.svg                          0 KB
  09 For a designer/tokens.css                             5 KB
  09 For a designer/tokens.json                            4 KB
  09 For a designer/templates.json                         7 KB

  54 files